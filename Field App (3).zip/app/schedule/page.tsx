"use client"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Home, MapPin, Scan, Calendar, Search, MoreVertical, Filter, ChevronDown, X } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"

export default function SchedulePage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isFilterOpen, setIsFilterOpen] = useState(false)
  const [isAgencyDropdownOpen, setIsAgencyDropdownOpen] = useState(false)
  const [selectedAgency, setSelectedAgency] = useState("All Agencies")
  const [searchQuery, setSearchQuery] = useState("")

  const menuRef = useRef<HTMLDivElement>(null)
  const filterRef = useRef<HTMLDivElement>(null)
  const agencyDropdownRef = useRef<HTMLDivElement>(null)

  // Filter states
  const [sortBy, setSortBy] = useState("date")
  const [filters, setFilters] = useState({
    status: [] as string[],
    side: [] as string[],
    dateFrom: "",
    dateTo: "",
    location: "",
  })

  // Sample agencies for dropdown
  const agencies = [
    "All Agencies",
    "CROWN",
    "City Water",
    "County Utilities",
    "Metro Water District",
    "Regional Water Authority",
  ]

  // Sample locations for dropdown
  const locations = [
    "San Francisco, CA",
    "Oakland, CA",
    "Berkeley, CA",
    "Palo Alto, CA",
    "San Jose, CA",
    "Fremont, CA",
    "Hayward, CA",
  ]

  // Sample schedule data
  const scheduleItems = [
    {
      id: 1,
      address: "1042 Oakwood Ln",
      scanDate: "TBA",
      company: "CROWN",
      status: "upcoming",
      side: "public",
    },
    {
      id: 2,
      address: "1042 Oakwood Ln",
      scanDate: "1/5/2025",
      company: "CROWN",
      status: "completed",
      side: "client",
    },
    {
      id: 3,
      address: "1042 Oakwood Ln",
      scanDate: "1/5/2025",
      company: "City Water",
      status: "completed",
      side: "public",
    },
    {
      id: 4,
      address: "1042 Oakwood Ln",
      scanDate: "1/5/2025",
      company: "County Utilities",
      status: "abandoned",
      side: "client",
    },
    {
      id: 5,
      address: "750 La Playa St",
      scanDate: "1/9/2025",
      company: "Metro Water District",
      status: "upcoming",
      side: "public",
    },
    {
      id: 6,
      address: "500 Parnassus Ave",
      scanDate: "1/10/2025",
      company: "Regional Water Authority",
      status: "completed",
      side: "client",
    },
  ]

  const handleEdit = (id: number) => {
    console.log("Edit item:", id)
    setIsMenuOpen(false)
  }

  const handleAbandon = (id: number) => {
    if (confirm("Are you sure you want to abandon this scan? This action cannot be undone.")) {
      console.log("Abandon item:", id)
    }
    setIsMenuOpen(false)
  }

  const handleFilterChange = (type: string, value: string) => {
    if (type === "status" || type === "side") {
      setFilters((prev) => {
        const currentValues = [...prev[type]]
        if (currentValues.includes(value)) {
          return {
            ...prev,
            [type]: currentValues.filter((item) => item !== value),
          }
        } else {
          return {
            ...prev,
            [type]: [...currentValues, value],
          }
        }
      })
    } else {
      setFilters((prev) => ({
        ...prev,
        [type]: value,
      }))
    }
  }

  const clearFilters = () => {
    setFilters({
      status: [],
      side: [],
      dateFrom: "",
      dateTo: "",
      location: "",
    })
    setSortBy("date")
  }

  const applyFilters = () => {
    console.log("Applied filters:", filters)
    console.log("Sort by:", sortBy)
    setIsFilterOpen(false)
  }

  const handleAgencySelect = (agency: string) => {
    setSelectedAgency(agency)
    setIsAgencyDropdownOpen(false)
    console.log("Selected agency:", agency)
  }

  // Filter schedule items based on selected agency and search query
  const filteredItems = scheduleItems.filter((item) => {
    const matchesAgency = selectedAgency === "All Agencies" || item.company === selectedAgency
    const matchesSearch =
      item.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.company.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesAgency && matchesSearch
  })

  // Close menus when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false)
      }
      if (filterRef.current && !filterRef.current.contains(event.target as Node)) {
        setIsFilterOpen(false)
      }
      if (agencyDropdownRef.current && !agencyDropdownRef.current.contains(event.target as Node)) {
        setIsAgencyDropdownOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  return (
    <div className="max-w-md mx-auto bg-background dark:bg-gray-900 min-h-screen flex flex-col">
      {/* Header */}
      <div className="p-6 pb-4">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-3xl font-bold text-[#1e1e1e] dark:text-white">My Schedule</h1>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <div className="relative" ref={filterRef}>
              <button onClick={() => setIsFilterOpen(!isFilterOpen)} className="p-2" aria-label="Filter">
                <Filter className="text-[#a5a5a5] dark:text-gray-400" />
              </button>

              {isFilterOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-white dark:bg-gray-800 rounded-md shadow-lg z-10 border border-[#e5e7eb] dark:border-gray-700">
                  <div className="p-4">
                    <h3 className="font-bold text-lg mb-3 text-[#1e1e1e] dark:text-white">Sort By</h3>
                    <div className="space-y-2 mb-4">
                      <label className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="sortBy"
                          value="name"
                          checked={sortBy === "name"}
                          onChange={() => setSortBy("name")}
                          className="accent-[#f47e20]"
                        />
                        <span className="font-mono text-[#1e1e1e] dark:text-white">Name</span>
                      </label>
                      <label className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="sortBy"
                          value="date"
                          checked={sortBy === "date"}
                          onChange={() => setSortBy("date")}
                          className="accent-[#f47e20]"
                        />
                        <span className="font-mono text-[#1e1e1e] dark:text-white">Date</span>
                      </label>
                      <label className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="sortBy"
                          value="location"
                          checked={sortBy === "location"}
                          onChange={() => setSortBy("location")}
                          className="accent-[#f47e20]"
                        />
                        <span className="font-mono text-[#1e1e1e] dark:text-white">Location</span>
                      </label>
                    </div>

                    <h3 className="font-bold text-lg mb-3 text-[#1e1e1e] dark:text-white">Filter By</h3>
                    <div className="mb-3">
                      <h4 className="font-medium mb-2 text-[#1e1e1e] dark:text-white">Status</h4>
                      <div className="space-y-2 ml-2">
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={filters.status.includes("upcoming")}
                            onChange={() => handleFilterChange("status", "upcoming")}
                            className="accent-[#f47e20]"
                          />
                          <span className="font-mono text-[#1e1e1e] dark:text-white">Upcoming</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={filters.status.includes("completed")}
                            onChange={() => handleFilterChange("status", "completed")}
                            className="accent-[#f47e20]"
                          />
                          <span className="font-mono text-[#1e1e1e] dark:text-white">Completed</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={filters.status.includes("abandoned")}
                            onChange={() => handleFilterChange("status", "abandoned")}
                            className="accent-[#f47e20]"
                          />
                          <span className="font-mono text-[#1e1e1e] dark:text-white">Abandoned</span>
                        </label>
                      </div>
                    </div>

                    <div className="mb-3">
                      <h4 className="font-medium mb-2 text-[#1e1e1e] dark:text-white">Side</h4>
                      <div className="space-y-2 ml-2">
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={filters.side.includes("public")}
                            onChange={() => handleFilterChange("side", "public")}
                            className="accent-[#f47e20]"
                          />
                          <span className="font-mono text-[#1e1e1e] dark:text-white">Public Side</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={filters.side.includes("client")}
                            onChange={() => handleFilterChange("side", "client")}
                            className="accent-[#f47e20]"
                          />
                          <span className="font-mono text-[#1e1e1e] dark:text-white">Client Side</span>
                        </label>
                      </div>
                    </div>

                    <div className="mb-3">
                      <h4 className="font-medium mb-2 text-[#1e1e1e] dark:text-white">Date Range</h4>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-xs text-[#6b7280] dark:text-gray-400 font-mono">From</label>
                          <input
                            type="date"
                            value={filters.dateFrom}
                            onChange={(e) => handleFilterChange("dateFrom", e.target.value)}
                            className="w-full border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-2 font-mono text-sm"
                          />
                        </div>
                        <div>
                          <label className="text-xs text-[#6b7280] dark:text-gray-400 font-mono">To</label>
                          <input
                            type="date"
                            value={filters.dateTo}
                            onChange={(e) => handleFilterChange("dateTo", e.target.value)}
                            className="w-full border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-2 font-mono text-sm"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <h4 className="font-medium mb-2 text-[#1e1e1e] dark:text-white">Location</h4>
                      <div className="relative">
                        <select
                          value={filters.location}
                          onChange={(e) => handleFilterChange("location", e.target.value)}
                          className="w-full border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-2 font-mono appearance-none"
                        >
                          <option value="">Select location</option>
                          {locations.map((location, index) => (
                            <option key={index} value={location}>
                              {location}
                            </option>
                          ))}
                        </select>
                        <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
                          <ChevronDown className="text-[#1e1e1e] dark:text-white h-4 w-4" />
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={clearFilters}
                        className="flex-1 py-2 px-4 border border-[#d9d9d9] dark:border-gray-700 text-[#1e1e1e] dark:text-white rounded-lg font-mono"
                      >
                        Clear
                      </button>
                      <button
                        onClick={applyFilters}
                        className="flex-1 py-2 px-4 bg-[#f47e20] text-white rounded-lg font-mono"
                      >
                        Apply
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div className="relative" ref={menuRef}>
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2" aria-label="Menu">
                <MoreVertical className="text-[#a5a5a5] dark:text-gray-400" />
              </button>

              {isMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg z-10 border border-[#e5e7eb] dark:border-gray-700">
                  <div className="py-1">
                    <button
                      onClick={() => handleEdit(1)}
                      className="block w-full text-left px-4 py-2 text-sm font-mono text-[#1e1e1e] dark:text-white hover:bg-[#f1f4ff] dark:hover:bg-gray-700"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleAbandon(1)}
                      className="block w-full text-left px-4 py-2 text-sm font-mono text-[#f05252] hover:bg-[#f1f4ff] dark:hover:bg-gray-700"
                    >
                      Abandon
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Search Bar with Agencies Dropdown */}
        <div className="flex border border-[#d9d9d9] dark:border-gray-700 rounded-full overflow-hidden mb-6">
          <div className="relative" ref={agencyDropdownRef}>
            <button
              onClick={() => setIsAgencyDropdownOpen(!isAgencyDropdownOpen)}
              className="flex items-center border-r border-[#d9d9d9] dark:border-gray-700 px-4 py-2 min-w-[120px]"
            >
              <span className="text-[#6b7280] dark:text-gray-400 font-mono">{selectedAgency}</span>
              <ChevronDown className="ml-2 h-4 w-4 text-[#6b7280] dark:text-gray-400" />
            </button>

            {isAgencyDropdownOpen && (
              <div className="absolute left-0 top-full mt-1 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg z-10 border border-[#e5e7eb] dark:border-gray-700">
                <div className="py-1">
                  {agencies.map((agency, index) => (
                    <button
                      key={index}
                      onClick={() => handleAgencySelect(agency)}
                      className={`block w-full text-left px-4 py-2 text-sm font-mono ${
                        selectedAgency === agency
                          ? "bg-[#f1f4ff] dark:bg-gray-700 text-[#f47e20]"
                          : "text-[#6b7280] dark:text-gray-300"
                      } hover:bg-[#f1f4ff] dark:hover:bg-gray-700`}
                    >
                      {agency}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div className="flex-1 flex items-center px-4">
            <input
              type="text"
              placeholder="Search"
              className="w-full outline-none font-mono text-[#6b7280] dark:text-gray-400 bg-transparent"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="h-5 w-5 text-[#6b7280] dark:text-gray-400" />
          </div>
        </div>
      </div>

      {/* Schedule Items */}
      <div className="px-6 pb-20">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className="mb-6 border border-[#e5e7eb] dark:border-gray-700 rounded-xl p-4 shadow-sm dark:bg-gray-800"
          >
            <div className="flex">
              <div className="flex-1 overflow-hidden">
                <h3 className="text-base text-[#6b7280] dark:text-gray-300 font-medium truncate">{item.address}</h3>
                <p className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono truncate">
                  Scan Date: {item.scanDate}
                </p>
                <p className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono truncate">
                  Company: {item.company}
                </p>

                <div className="flex items-center mt-4">
                  {item.status === "upcoming" && (
                    <div className="flex items-center">
                      <div className="w-4 h-4 rounded-full border-2 border-[#1c64f2] flex items-center justify-center">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#1c64f2]"></div>
                      </div>
                      <span className="ml-1 text-xs text-[#1c64f2] font-mono">Upcoming</span>
                    </div>
                  )}
                  {item.status === "completed" && (
                    <div className="flex items-center">
                      <div className="w-4 h-4 rounded-full bg-[#0e9f6e] flex items-center justify-center">
                        <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                      </div>
                      <span className="ml-1 text-xs text-[#0e9f6e] font-mono">Completed</span>
                    </div>
                  )}
                  {item.status === "abandoned" && (
                    <div className="flex items-center">
                      <div className="w-4 h-4 rounded-full bg-[#f05252] flex items-center justify-center">
                        <X className="w-2 h-2 text-white" />
                      </div>
                      <span className="ml-1 text-xs text-[#f05252] font-mono">Abandoned</span>
                    </div>
                  )}
                </div>
              </div>
              <div className="w-24 h-24 bg-[#d9d9d9] dark:bg-gray-700 rounded-md overflow-hidden ml-2 flex-shrink-0">
                <Image
                  src="/placeholder.svg?height=96&width=96"
                  alt="Map"
                  width={96}
                  height={96}
                  className="object-cover w-full h-full"
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-[#e5e7eb] dark:border-gray-700 py-2 max-w-md mx-auto">
        <div className="flex justify-around items-center">
          <Link href="/" className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#6b7280] dark:text-gray-400">
              <Home strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono">Home</span>
          </Link>
          <Link href="/sites" className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#6b7280] dark:text-gray-400">
              <MapPin strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono">Sites</span>
          </Link>
          <Link href="/new-scan" className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#6b7280] dark:text-gray-400">
              <Scan strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono">New Scan</span>
          </Link>
          <div className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#f47e20]">
              <Calendar strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#f47e20] mt-1 font-mono">Schedule</span>
          </div>
        </div>
      </div>
    </div>
  )
}

