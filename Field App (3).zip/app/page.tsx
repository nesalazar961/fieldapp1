import Image from "next/image"
import { Home, MapPin, Scan, Calendar } from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"

export default function FieldApp() {
  return (
    <div className="max-w-md mx-auto bg-background dark:bg-gray-900 min-h-screen flex flex-col">
      {/* Header with profile */}
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <div className="relative w-16 h-16 rounded-full overflow-hidden">
              <Image
                src="/placeholder.svg?height=64&width=64"
                alt="Profile"
                width={64}
                height={64}
                className="object-cover"
              />
            </div>
            <h1 className="text-3xl font-bold text-[#1e1e1e] dark:text-white">Hi John</h1>
          </div>
          <ThemeToggle />
        </div>

        {/* Date */}
        <div className="mt-4 mb-4">
          <h2 className="text-2xl font-bold text-[#1e1e1e] dark:text-white">Today 1/10/2025</h2>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="border border-[#e5e7eb] dark:border-gray-700 rounded-xl p-4 shadow-sm dark:bg-gray-800">
            <p className="text-3xl font-bold text-[#1c64f2]">80</p>
            <p className="text-[#9ca3af] dark:text-gray-400 text-lg font-mono">Upcoming Sites</p>
          </div>
          <div className="border border-[#e5e7eb] dark:border-gray-700 rounded-xl p-4 shadow-sm dark:bg-gray-800">
            <p className="text-3xl font-bold text-[#0e9f6e]">200</p>
            <p className="text-[#9ca3af] dark:text-gray-400 text-lg font-mono">Completed Sites</p>
          </div>
          <div className="border border-[#e5e7eb] dark:border-gray-700 rounded-xl p-4 shadow-sm dark:bg-gray-800">
            <p className="text-3xl font-bold text-[#f05252]">20</p>
            <p className="text-[#9ca3af] dark:text-gray-400 text-lg font-mono">Abandoned Sites</p>
          </div>
          <div className="border border-[#e5e7eb] dark:border-gray-700 rounded-xl p-4 shadow-sm dark:bg-gray-800">
            <p className="text-3xl font-bold text-[#f47e20]">10,000</p>
            <p className="text-[#9ca3af] dark:text-gray-400 text-lg font-mono">Total Sites</p>
          </div>
        </div>

        {/* Recently Completed Sites */}
        <div className="mb-20">
          <h2 className="text-2xl font-bold text-[#1e1e1e] dark:text-white mb-4">Recently Completed Sites</h2>

          {/* Site Card 1 */}
          <div className="border border-[#e5e7eb] dark:border-gray-700 rounded-xl p-4 mb-4 shadow-sm dark:bg-gray-800">
            <div className="flex">
              <div className="flex-1">
                <h3 className="text-xl text-[#6b7280] dark:text-gray-300 font-medium">1987 Hyde St</h3>
                <div className="flex items-center gap-1 mt-1">
                  <p className="text-sm font-mono dark:text-gray-400">Status:</p>
                  <p className="text-[#1c64f2] text-sm font-mono">Upcoming</p>
                </div>
                <p className="text-[#6b7280] dark:text-gray-400 text-sm mt-1 font-mono">Date: 1/5/2025 11:33 AM</p>
                <p className="text-[#6b7280] dark:text-gray-400 text-sm mt-1 font-mono">Company: CROWN</p>
                <p className="text-[#6b7280] dark:text-gray-400 text-sm mt-1 font-mono">Field Worker: John Doe</p>

                <div className="flex items-center mt-4 gap-4">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-[#f47e20] flex items-center justify-center">
                      <div className="w-2 h-2 rounded-full bg-white"></div>
                    </div>
                    <span className="text-sm font-mono dark:text-gray-300">Public Side</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full border border-[#f47e20] flex items-center justify-center"></div>
                    <span className="text-sm font-mono dark:text-gray-300">Client Side</span>
                  </div>
                </div>
              </div>
              <div className="w-24 h-24 bg-[#d9d9d9] dark:bg-gray-700 rounded-md overflow-hidden ml-2">
                <Image
                  src="/placeholder.svg?height=96&width=96"
                  alt="Map"
                  width={96}
                  height={96}
                  className="object-cover w-full h-full"
                />
              </div>
            </div>
          </div>

          {/* Site Card 2 */}
          <div className="border border-[#e5e7eb] dark:border-gray-700 rounded-xl p-4 shadow-sm dark:bg-gray-800">
            <div className="flex">
              <div className="flex-1">
                <h3 className="text-xl text-[#6b7280] dark:text-gray-300 font-medium">1042 Oakwood Ln</h3>
                <div className="flex items-center gap-1 mt-1">
                  <p className="text-sm font-mono dark:text-gray-400">Status:</p>
                  <p className="text-[#0e9f6e] text-sm font-mono">Completed</p>
                </div>
                <p className="text-[#6b7280] dark:text-gray-400 text-sm mt-1 font-mono">Date: 1/5/2025 11:03 AM</p>
                <p className="text-[#6b7280] dark:text-gray-400 text-sm mt-1 font-mono">Company: CROWN</p>
                <p className="text-[#6b7280] dark:text-gray-400 text-sm mt-1 font-mono">Field Worker: John Doe</p>

                <div className="flex items-center mt-4 gap-4">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-[#f47e20] flex items-center justify-center">
                      <div className="w-2 h-2 rounded-full bg-white"></div>
                    </div>
                    <span className="text-sm font-mono dark:text-gray-300">Public Side</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full border border-[#f47e20] flex items-center justify-center"></div>
                    <span className="text-sm font-mono dark:text-gray-300">Client Side</span>
                  </div>
                </div>
              </div>
              <div className="w-24 h-24 bg-[#d9d9d9] dark:bg-gray-700 rounded-md overflow-hidden ml-2">
                <Image
                  src="/placeholder.svg?height=96&width=96"
                  alt="Map"
                  width={96}
                  height={96}
                  className="object-cover w-full h-full"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-[#e5e7eb] dark:border-gray-700 py-2 max-w-md mx-auto">
        <div className="flex justify-around items-center">
          <div className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#f47e20]">
              <Home strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#f47e20] mt-1 font-mono">Home</span>
          </div>
          <Link href="/sites" className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#6b7280] dark:text-gray-400">
              <MapPin strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono">Sites</span>
          </Link>
          <Link href="/new-scan" className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#6b7280] dark:text-gray-400">
              <Scan strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono">New Scan</span>
          </Link>
          <Link href="/schedule" className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#6b7280] dark:text-gray-400">
              <Calendar strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono">Schedule</span>
          </Link>
        </div>
      </div>
    </div>
  )
}

