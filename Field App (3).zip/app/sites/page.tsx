"use client"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import {
  Home,
  MapPin,
  Scan,
  Calendar,
  Search,
  MoreVertical,
  Filter,
  ChevronDown,
  X,
  Map,
  LayoutGrid,
} from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"

export default function SitesPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isFilterOpen, setIsFilterOpen] = useState(false)
  const [viewMode, setViewMode] = useState("map") // 'map' or 'grid'
  const [selectedSite, setSelectedSite] = useState<any>(null)
  const [isAgencyDropdownOpen, setIsAgencyDropdownOpen] = useState(false)
  const [isLocationDropdownOpen, setIsLocationDropdownOpen] = useState(false)
  const [selectedAgency, setSelectedAgency] = useState("All Agencies")
  const [selectedLocation, setSelectedLocation] = useState("")
  const [searchQuery, setSearchQuery] = useState("")

  const menuRef = useRef<HTMLDivElement>(null)
  const filterRef = useRef<HTMLDivElement>(null)
  const agencyDropdownRef = useRef<HTMLDivElement>(null)
  const locationDropdownRef = useRef<HTMLDivElement>(null)

  // Filter states
  const [sortBy, setSortBy] = useState("date")
  const [filters, setFilters] = useState({
    status: [] as string[],
    side: [] as string[],
    dateFrom: "",
    dateTo: "",
    location: "",
  })

  // Sample agencies for dropdown
  const agencies = [
    "All Agencies",
    "CROWN",
    "City Water",
    "County Utilities",
    "Metro Water District",
    "Regional Water Authority",
  ]

  // Sample locations for dropdown
  const locations = [
    "All Locations",
    "San Francisco, CA",
    "Oakland, CA",
    "Berkeley, CA",
    "Palo Alto, CA",
    "San Jose, CA",
    "Fremont, CA",
    "Hayward, CA",
  ]

  // Sample site data with more details and locations
  const sitePoints = [
    {
      id: 1,
      lat: 37.7749,
      lng: -122.4194,
      status: "upcoming",
      address: "1987 Hyde St",
      date: "1/5/2025 11:33 AM",
      company: "CROWN",
      fieldWorker: "John Doe",
      side: "public", // 'public' or 'client'
      location: "San Francisco, CA",
    },
    {
      id: 2,
      lat: 37.7833,
      lng: -122.4167,
      status: "completed",
      address: "1042 Oakwood Ln",
      date: "1/5/2025 11:03 AM",
      company: "CROWN",
      fieldWorker: "John Doe",
      side: "client",
      location: "San Francisco, CA",
    },
    {
      id: 3,
      lat: 37.7694,
      lng: -122.4862,
      status: "completed",
      address: "2250 Market St",
      date: "1/7/2025 9:15 AM",
      company: "City Water",
      fieldWorker: "Jane Smith",
      side: "public",
      location: "San Francisco, CA",
    },
    {
      id: 4,
      lat: 37.7831,
      lng: -122.4039,
      status: "abandoned",
      address: "1042 Oakwood Ln",
      date: "1/5/2025 11:03 AM",
      company: "CROWN",
      fieldWorker: "John Doe",
      side: "client",
      location: "Oakland, CA",
    },
    {
      id: 5,
      lat: 37.7644,
      lng: -122.4302,
      status: "upcoming",
      address: "750 La Playa St",
      date: "1/9/2025 1:30 PM",
      company: "County Utilities",
      fieldWorker: "John Doe",
      side: "client",
      location: "Berkeley, CA",
    },
    {
      id: 6,
      lat: 37.7558,
      lng: -122.4449,
      status: "completed",
      address: "500 Parnassus Ave",
      date: "1/10/2025 11:45 AM",
      company: "Metro Water District",
      fieldWorker: "Jane Smith",
      side: "public",
      location: "Palo Alto, CA",
    },
    {
      id: 7,
      lat: 37.7648,
      lng: -122.4636,
      status: "upcoming",
      address: "1825 Haight St",
      date: "1/11/2025 10:00 AM",
      company: "CROWN",
      fieldWorker: "John Doe",
      side: "client",
      location: "San Jose, CA",
    },
    {
      id: 8,
      lat: 37.7517,
      lng: -122.4567,
      status: "completed",
      address: "1100 Lake St",
      date: "1/12/2025 3:15 PM",
      company: "Regional Water Authority",
      fieldWorker: "Jane Smith",
      side: "public",
      location: "Fremont, CA",
    },
    {
      id: 9,
      lat: 37.7751,
      lng: -122.4193,
      status: "abandoned",
      address: "450 Sutter St",
      date: "1/13/2025 9:30 AM",
      company: "CROWN",
      fieldWorker: "John Doe",
      side: "client",
      location: "Hayward, CA",
    },
    {
      id: 10,
      lat: 37.7899,
      lng: -122.4033,
      status: "upcoming",
      address: "2001 Van Ness Ave",
      date: "1/14/2025 1:00 PM",
      company: "City Water",
      fieldWorker: "Jane Smith",
      side: "public",
      location: "San Francisco, CA",
    },
  ]

  const handleEdit = (id: number) => {
    console.log("Edit item:", id)
    setIsMenuOpen(false)
  }

  const handleAbandon = (id: number) => {
    if (confirm("Are you sure you want to abandon this site? This action cannot be undone.")) {
      console.log("Abandon item:", id)
    }
    setIsMenuOpen(false)
  }

  const handleFilterChange = (type: string, value: string) => {
    if (type === "status" || type === "side") {
      setFilters((prev) => {
        const currentValues = [...prev[type]]
        if (currentValues.includes(value)) {
          return {
            ...prev,
            [type]: currentValues.filter((item) => item !== value),
          }
        } else {
          return {
            ...prev,
            [type]: [...currentValues, value],
          }
        }
      })
    } else {
      setFilters((prev) => ({
        ...prev,
        [type]: value,
      }))
    }
  }

  const clearFilters = () => {
    setFilters({
      status: [],
      side: [],
      dateFrom: "",
      dateTo: "",
      location: "",
    })
    setSortBy("date")
    setSelectedLocation("")
  }

  const applyFilters = () => {
    console.log("Applied filters:", filters)
    console.log("Sort by:", sortBy)
    setIsFilterOpen(false)
  }

  const handleSiteClick = (site: any) => {
    setSelectedSite(site)
    console.log("Selected site:", site)
  }

  const closeSelectedSite = () => {
    setSelectedSite(null)
  }

  const handleAgencySelect = (agency: string) => {
    setSelectedAgency(agency)
    setIsAgencyDropdownOpen(false)
    console.log("Selected agency:", agency)
  }

  const handleLocationSelect = (location: string) => {
    setSelectedLocation(location)
    setIsLocationDropdownOpen(false)
    console.log("Selected location:", location)
    // Also update the filter
    handleFilterChange("location", location === "All Locations" ? "" : location)
  }

  // Get status color based on status
  const getStatusColor = (status: string) => {
    switch (status) {
      case "upcoming":
        return "text-[#1c64f2]" // Blue
      case "completed":
        return "text-[#0e9f6e]" // Green
      case "abandoned":
        return "text-[#f05252]" // Red
      default:
        return "text-[#6b7280]" // Gray
    }
  }

  // Filter sites based on selected agency, location, and search query
  const filteredSites = sitePoints.filter((site) => {
    const matchesAgency = selectedAgency === "All Agencies" || site.company === selectedAgency
    const matchesLocation =
      selectedLocation === "" || selectedLocation === "All Locations" || site.location === selectedLocation
    const matchesSearch =
      site.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      site.company.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesAgency && matchesLocation && matchesSearch
  })

  // Close menus when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false)
      }
      if (filterRef.current && !filterRef.current.contains(event.target as Node)) {
        setIsFilterOpen(false)
      }
      if (agencyDropdownRef.current && !agencyDropdownRef.current.contains(event.target as Node)) {
        setIsAgencyDropdownOpen(false)
      }
      if (locationDropdownRef.current && !locationDropdownRef.current.contains(event.target as Node)) {
        setIsLocationDropdownOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  return (
    <div className="max-w-md mx-auto bg-background dark:bg-gray-900 min-h-screen flex flex-col">
      {/* Header */}
      <div className="p-6 pb-4">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-3xl font-bold text-[#1e1e1e] dark:text-white">Work Sites</h1>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <button
              onClick={() => setViewMode("map")}
              className={`p-2 ${viewMode === "map" ? "text-[#f47e20]" : "text-[#a5a5a5] dark:text-gray-400"}`}
              aria-label="Map View"
            >
              <Map className="h-5 w-5" />
            </button>
            <button
              onClick={() => setViewMode("grid")}
              className={`p-2 ${viewMode === "grid" ? "text-[#f47e20]" : "text-[#a5a5a5] dark:text-gray-400"}`}
              aria-label="Grid View"
            >
              <LayoutGrid className="h-5 w-5" />
            </button>
            <div className="relative" ref={filterRef}>
              <button onClick={() => setIsFilterOpen(!isFilterOpen)} className="p-2" aria-label="Filter">
                <Filter className="text-[#a5a5a5] dark:text-gray-400" />
              </button>

              {isFilterOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-white dark:bg-gray-800 rounded-md shadow-lg z-10 border border-[#e5e7eb] dark:border-gray-700">
                  <div className="p-4">
                    <h3 className="font-bold text-lg mb-3 text-[#1e1e1e] dark:text-white">Sort By</h3>
                    <div className="space-y-2 mb-4">
                      <label className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="sortBy"
                          value="name"
                          checked={sortBy === "name"}
                          onChange={() => setSortBy("name")}
                          className="accent-[#f47e20]"
                        />
                        <span className="font-mono text-[#1e1e1e] dark:text-white">Name</span>
                      </label>
                      <label className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="sortBy"
                          value="date"
                          checked={sortBy === "date"}
                          onChange={() => setSortBy("date")}
                          className="accent-[#f47e20]"
                        />
                        <span className="font-mono text-[#1e1e1e] dark:text-white">Date</span>
                      </label>
                      <label className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="sortBy"
                          value="location"
                          checked={sortBy === "location"}
                          onChange={() => setSortBy("location")}
                          className="accent-[#f47e20]"
                        />
                        <span className="font-mono text-[#1e1e1e] dark:text-white">Location</span>
                      </label>
                    </div>

                    <h3 className="font-bold text-lg mb-3 text-[#1e1e1e] dark:text-white">Filter By</h3>
                    <div className="mb-3">
                      <h4 className="font-medium mb-2 text-[#1e1e1e] dark:text-white">Status</h4>
                      <div className="space-y-2 ml-2">
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={filters.status.includes("upcoming")}
                            onChange={() => handleFilterChange("status", "upcoming")}
                            className="accent-[#f47e20]"
                          />
                          <span className="font-mono text-[#1e1e1e] dark:text-white">Upcoming</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={filters.status.includes("completed")}
                            onChange={() => handleFilterChange("status", "completed")}
                            className="accent-[#f47e20]"
                          />
                          <span className="font-mono text-[#1e1e1e] dark:text-white">Completed</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={filters.status.includes("abandoned")}
                            onChange={() => handleFilterChange("status", "abandoned")}
                            className="accent-[#f47e20]"
                          />
                          <span className="font-mono text-[#1e1e1e] dark:text-white">Abandoned</span>
                        </label>
                      </div>
                    </div>

                    <div className="mb-3">
                      <h4 className="font-medium mb-2 text-[#1e1e1e] dark:text-white">Side</h4>
                      <div className="space-y-2 ml-2">
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={filters.side.includes("public")}
                            onChange={() => handleFilterChange("side", "public")}
                            className="accent-[#f47e20]"
                          />
                          <span className="font-mono text-[#1e1e1e] dark:text-white">Public Side</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={filters.side.includes("client")}
                            onChange={() => handleFilterChange("side", "client")}
                            className="accent-[#f47e20]"
                          />
                          <span className="font-mono text-[#1e1e1e] dark:text-white">Client Side</span>
                        </label>
                      </div>
                    </div>

                    <div className="mb-3">
                      <h4 className="font-medium mb-2 text-[#1e1e1e] dark:text-white">Date Range</h4>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-xs text-[#6b7280] dark:text-gray-400 font-mono">From</label>
                          <input
                            type="date"
                            value={filters.dateFrom}
                            onChange={(e) => handleFilterChange("dateFrom", e.target.value)}
                            className="w-full border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-2 font-mono text-sm"
                          />
                        </div>
                        <div>
                          <label className="text-xs text-[#6b7280] dark:text-gray-400 font-mono">To</label>
                          <input
                            type="date"
                            value={filters.dateTo}
                            onChange={(e) => handleFilterChange("dateTo", e.target.value)}
                            className="w-full border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-2 font-mono text-sm"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <h4 className="font-medium mb-2 text-[#1e1e1e] dark:text-white">Location</h4>
                      <div className="relative" ref={locationDropdownRef}>
                        <button
                          onClick={() => setIsLocationDropdownOpen(!isLocationDropdownOpen)}
                          className="w-full flex justify-between items-center border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-2 font-mono text-sm"
                        >
                          <span>{selectedLocation || "Select location"}</span>
                          <ChevronDown className="h-4 w-4 text-[#6b7280] dark:text-gray-400" />
                        </button>

                        {isLocationDropdownOpen && (
                          <div className="absolute left-0 right-0 mt-1 bg-white dark:bg-gray-800 rounded-md shadow-lg z-10 border border-[#e5e7eb] dark:border-gray-700 max-h-48 overflow-y-auto">
                            <div className="py-1">
                              {locations.map((location, index) => (
                                <button
                                  key={index}
                                  onClick={() => handleLocationSelect(location)}
                                  className={`block w-full text-left px-4 py-2 text-sm font-mono ${
                                    selectedLocation === location
                                      ? "bg-[#f1f4ff] dark:bg-gray-700 text-[#f47e20]"
                                      : "text-[#6b7280] dark:text-gray-300"
                                  } hover:bg-[#f1f4ff] dark:hover:bg-gray-700`}
                                >
                                  {location}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={clearFilters}
                        className="flex-1 py-2 px-4 border border-[#d9d9d9] dark:border-gray-700 text-[#1e1e1e] dark:text-white rounded-lg font-mono"
                      >
                        Clear
                      </button>
                      <button
                        onClick={applyFilters}
                        className="flex-1 py-2 px-4 bg-[#f47e20] text-white rounded-lg font-mono"
                      >
                        Apply
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div className="relative" ref={menuRef}>
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2" aria-label="Menu">
                <MoreVertical className="text-[#a5a5a5] dark:text-gray-400" />
              </button>

              {isMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg z-10 border border-[#e5e7eb] dark:border-gray-700">
                  <div className="py-1">
                    <button
                      onClick={() => handleEdit(1)}
                      className="block w-full text-left px-4 py-2 text-sm font-mono text-[#1e1e1e] dark:text-white hover:bg-[#f1f4ff] dark:hover:bg-gray-700"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleAbandon(1)}
                      className="block w-full text-left px-4 py-2 text-sm font-mono text-[#f05252] hover:bg-[#f1f4ff] dark:hover:bg-gray-700"
                    >
                      Abandon
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Search Bar with Agencies Dropdown */}
        <div className="flex border border-[#d9d9d9] dark:border-gray-700 rounded-full overflow-hidden mb-6">
          <div className="relative" ref={agencyDropdownRef}>
            <button
              onClick={() => setIsAgencyDropdownOpen(!isAgencyDropdownOpen)}
              className="flex items-center border-r border-[#d9d9d9] dark:border-gray-700 px-4 py-2 min-w-[120px]"
            >
              <span className="text-[#6b7280] dark:text-gray-400 font-mono">{selectedAgency}</span>
              <ChevronDown className="ml-2 h-4 w-4 text-[#6b7280] dark:text-gray-400" />
            </button>

            {isAgencyDropdownOpen && (
              <div className="absolute left-0 top-full mt-1 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg z-10 border border-[#e5e7eb] dark:border-gray-700">
                <div className="py-1">
                  {agencies.map((agency, index) => (
                    <button
                      key={index}
                      onClick={() => handleAgencySelect(agency)}
                      className={`block w-full text-left px-4 py-2 text-sm font-mono ${
                        selectedAgency === agency
                          ? "bg-[#f1f4ff] dark:bg-gray-700 text-[#f47e20]"
                          : "text-[#6b7280] dark:text-gray-300"
                      } hover:bg-[#f1f4ff] dark:hover:bg-gray-700`}
                    >
                      {agency}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div className="flex-1 flex items-center px-4">
            <input
              type="text"
              placeholder="Search"
              className="w-full outline-none font-mono text-[#6b7280] dark:text-gray-400 bg-transparent"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="h-5 w-5 text-[#6b7280] dark:text-gray-400" />
          </div>
        </div>
      </div>

      {/* Map View */}
      {viewMode === "map" && (
        <div className="flex-1 relative">
          <div className="absolute inset-0 bg-[#f1f1f1] dark:bg-gray-800">
            {/* Map background */}
            <Image
              src="/placeholder.svg?height=800&width=400"
              alt="Map"
              width={400}
              height={800}
              className="w-full h-full object-cover opacity-100 dark:opacity-80"
            />

            {/* Site points */}
            {filteredSites.map((point) => (
              <div
                key={point.id}
                className="absolute w-4 h-4 rounded-full bg-[#f47e20] transform -translate-x-1/2 -translate-y-1/2 cursor-pointer"
                style={{
                  left: `${(point.lng + 122.5) * 800}px`,
                  top: `${(37.8 - point.lat) * 800}px`,
                }}
                onClick={() => handleSiteClick(point)}
              />
            ))}
          </div>

          {/* Site Details Popup */}
          {selectedSite && (
            <div className="absolute bottom-0 left-0 right-0 bg-white dark:bg-gray-800 rounded-t-xl shadow-lg p-6 z-10 transition-transform duration-300 ease-in-out">
              <div className="mb-4">
                <h2 className="text-base text-[#6b7280] dark:text-gray-300 font-medium truncate">
                  {selectedSite.address}
                </h2>
                <p className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono truncate">
                  Date: {selectedSite.date}
                </p>
                <p className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono truncate">
                  Company: {selectedSite.company}
                </p>
                <p className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono truncate">
                  Field Worker: {selectedSite.fieldWorker}
                </p>
                <p className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono truncate">
                  Location: {selectedSite.location}
                </p>
              </div>

              <div className="flex items-center justify-between mt-4">
                <div className="flex items-center gap-1">
                  <div
                    className={`w-4 h-4 rounded-full ${selectedSite.side === "public" ? "bg-[#f47e20]" : "border border-[#f47e20]"} flex items-center justify-center`}
                  >
                    {selectedSite.side === "public" && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                  </div>
                  <span className="text-xs font-mono dark:text-gray-300">Public Side</span>
                </div>
                <div className="flex items-center gap-1">
                  <div
                    className={`w-4 h-4 rounded-full ${selectedSite.side === "client" ? "bg-[#f47e20]" : "border border-[#f47e20]"} flex items-center justify-center`}
                  >
                    {selectedSite.side === "client" && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                  </div>
                  <span className="text-xs font-mono dark:text-gray-300">Client Side</span>
                </div>
              </div>

              <button
                onClick={closeSelectedSite}
                className="absolute top-4 right-4 text-[#6b7280] dark:text-gray-400"
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* Grid View */}
      {viewMode === "grid" && (
        <div className="px-6 pb-20">
          {filteredSites.slice(0, 5).map((site) => (
            <div
              key={site.id}
              className="mb-6 border border-[#e5e7eb] dark:border-gray-700 rounded-xl p-6 shadow-sm dark:bg-gray-800"
            >
              <div className="flex">
                <div className="flex-1 overflow-hidden">
                  <h3 className="text-base text-[#6b7280] dark:text-gray-300 font-medium truncate">{site.address}</h3>
                  <div className="flex items-center gap-1 mt-1">
                    <p className="text-xs font-mono dark:text-gray-400">Status:</p>
                    <p className={`text-xs font-mono capitalize ${getStatusColor(site.status)}`}>{site.status}</p>
                  </div>
                  <p className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono truncate">Date: {site.date}</p>
                  <p className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono truncate">
                    Company: {site.company}
                  </p>
                  <p className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono truncate">
                    Field Worker: {site.fieldWorker}
                  </p>
                  <p className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono truncate">
                    Location: {site.location}
                  </p>

                  <div className="flex items-center justify-between mt-4">
                    <div className="flex items-center gap-1">
                      <div
                        className={`w-4 h-4 rounded-full ${site.side === "public" ? "bg-[#f47e20]" : "border border-[#f47e20]"} flex items-center justify-center`}
                      >
                        {site.side === "public" && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                      </div>
                      <span className="text-xs font-mono dark:text-gray-300">Public Side</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div
                        className={`w-4 h-4 rounded-full ${site.side === "client" ? "bg-[#f47e20]" : "border border-[#f47e20]"} flex items-center justify-center`}
                      >
                        {site.side === "client" && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                      </div>
                      <span className="text-xs font-mono dark:text-gray-300">Client Side</span>
                    </div>
                  </div>
                </div>
                <div className="w-24 h-24 bg-[#d9d9d9] dark:bg-gray-700 rounded-md overflow-hidden ml-4 flex-shrink-0">
                  <Image
                    src="/placeholder.svg?height=96&width=96"
                    alt="Map"
                    width={96}
                    height={96}
                    className="object-cover w-full h-full"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-[#e5e7eb] dark:border-gray-700 py-2 max-w-md mx-auto">
        <div className="flex justify-around items-center">
          <Link href="/" className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#6b7280] dark:text-gray-400">
              <Home strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono">Home</span>
          </Link>
          <div className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#f47e20]">
              <MapPin strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#f47e20] mt-1 font-mono">Sites</span>
          </div>
          <Link href="/new-scan" className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#6b7280] dark:text-gray-400">
              <Scan strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono">New Scan</span>
          </Link>
          <Link href="/schedule" className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#6b7280] dark:text-gray-400">
              <Calendar strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono">Schedule</span>
          </Link>
        </div>
      </div>
    </div>
  )
}

