"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { ChevronDown, Camera, MoreVertical, Home, MapPin, Scan, Calendar } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ThemeToggle } from "@/components/theme-toggle"

export default function NewScanPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    customerNumber: "",
    agency: "Agencies",
    address: "",
    city: "",
    state: "",
    zipcode: "",
    meterNumber: "",
    meterSize: "",
    operatorNotes: "",
  })
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
    // Here you would typically save to Supabase
    // Then navigate back to home or to a confirmation page
    router.push("/")
  }

  const handleSaveAsDraft = () => {
    console.log("Saving as draft:", formData)
    alert("Scan saved as draft")
    setIsMenuOpen(false)
    // Here you would save to Supabase with a status of "draft"
  }

  const handleAbandon = () => {
    if (confirm("Are you sure you want to abandon this scan? All data will be lost.")) {
      console.log("Scan abandoned")
      router.push("/")
    }
    setIsMenuOpen(false)
  }

  const handleEdit = () => {
    console.log("Edit mode activated")
    setIsMenuOpen(false)
    // This would typically just close the menu since we're already in edit mode
    // But you could add additional edit functionality here
  }

  // Close menu when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  // Get current date and time formatted
  const now = new Date()
  const formattedDate = now.toLocaleDateString("en-US", {
    month: "2-digit",
    day: "2-digit",
    year: "numeric",
  })
  const formattedTime = now.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  })
  const dateTimeString = `${formattedDate}, ${formattedTime}`

  // List of all 50 US states
  const usStates = [
    "AL",
    "AK",
    "AZ",
    "AR",
    "CA",
    "CO",
    "CT",
    "DE",
    "FL",
    "GA",
    "HI",
    "ID",
    "IL",
    "IN",
    "IA",
    "KS",
    "KY",
    "LA",
    "ME",
    "MD",
    "MA",
    "MI",
    "MN",
    "MS",
    "MO",
    "MT",
    "NE",
    "NV",
    "NH",
    "NJ",
    "NM",
    "NY",
    "NC",
    "ND",
    "OH",
    "OK",
    "OR",
    "PA",
    "RI",
    "SC",
    "SD",
    "TN",
    "TX",
    "UT",
    "VT",
    "VA",
    "WA",
    "WV",
    "WI",
    "WY",
  ]

  return (
    <div className="max-w-md mx-auto bg-background dark:bg-gray-900 min-h-screen flex flex-col">
      {/* Header */}
      <div className="p-6 pb-0">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-[#1e1e1e] dark:text-white">New Scan</h1>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="flex flex-col gap-1 items-center justify-center p-2"
                aria-label="Menu"
              >
                <MoreVertical className="text-[#a5a5a5] dark:text-gray-400" />
              </button>

              {isMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg z-10 border border-[#e5e7eb] dark:border-gray-700">
                  <div className="py-1">
                    <button
                      onClick={handleSaveAsDraft}
                      className="block w-full text-left px-4 py-2 text-sm font-mono text-[#1e1e1e] dark:text-white hover:bg-[#f1f4ff] dark:hover:bg-gray-700"
                    >
                      Save as Draft
                    </button>
                    <button
                      onClick={handleAbandon}
                      className="block w-full text-left px-4 py-2 text-sm font-mono text-[#f05252] hover:bg-[#f1f4ff] dark:hover:bg-gray-700"
                    >
                      Abandon
                    </button>
                    <button
                      onClick={handleEdit}
                      className="block w-full text-left px-4 py-2 text-sm font-mono text-[#1e1e1e] dark:text-white hover:bg-[#f1f4ff] dark:hover:bg-gray-700"
                    >
                      Edit
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="p-6 flex-1">
        <div className="space-y-6 mb-20">
          {/* Date and Time */}
          <div>
            <label className="block text-[#1e1e1e] dark:text-white text-xl mb-2">Date and Time</label>
            <p className="text-[#f47e20] text-xl font-mono">{dateTimeString}</p>
          </div>

          {/* Customer Number */}
          <div>
            <label htmlFor="customerNumber" className="block text-[#1e1e1e] dark:text-white text-xl mb-2">
              Customer Number
            </label>
            <input
              type="text"
              id="customerNumber"
              name="customerNumber"
              placeholder="customer number"
              className="w-full border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-4 font-mono"
              value={formData.customerNumber}
              onChange={handleChange}
            />
          </div>

          {/* Agency */}
          <div>
            <label htmlFor="agency" className="block text-[#1e1e1e] dark:text-white text-xl mb-2">
              Agency
            </label>
            <div className="relative">
              <select
                id="agency"
                name="agency"
                className="w-full border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-4 appearance-none font-mono"
                value={formData.agency}
                onChange={handleChange}
              >
                <option>Agencies</option>
                <option>CROWN</option>
                <option>City Water</option>
                <option>County Utilities</option>
              </select>
              <div className="absolute right-4 top-1/2 transform -translate-y-1/2 pointer-events-none">
                <ChevronDown className="text-[#1e1e1e] dark:text-white" />
              </div>
            </div>
          </div>

          {/* Address */}
          <div>
            <label htmlFor="address" className="block text-[#1e1e1e] dark:text-white text-xl mb-2">
              Address
            </label>
            <input
              type="text"
              id="address"
              name="address"
              placeholder="123 Address Ave,"
              className="w-full border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-4 mb-3 font-mono"
              value={formData.address}
              onChange={handleChange}
            />
            <input
              type="text"
              id="city"
              name="city"
              placeholder="City"
              className="w-full border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-4 mb-3 font-mono"
              value={formData.city}
              onChange={handleChange}
            />
            <div className="flex gap-3">
              <div className="w-1/3 relative">
                <select
                  id="state"
                  name="state"
                  className="w-full border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-4 appearance-none font-mono"
                  value={formData.state}
                  onChange={handleChange}
                >
                  <option value="">State</option>
                  {usStates.map((state) => (
                    <option key={state} value={state}>
                      {state}
                    </option>
                  ))}
                </select>
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
                  <ChevronDown className="text-[#1e1e1e] dark:text-white h-4 w-4" />
                </div>
              </div>
              <input
                type="text"
                id="zipcode"
                name="zipcode"
                placeholder="Zipcode"
                className="w-2/3 border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-4 font-mono"
                value={formData.zipcode}
                onChange={handleChange}
              />
            </div>
          </div>

          {/* Meter Number */}
          <div>
            <label htmlFor="meterNumber" className="block text-[#1e1e1e] dark:text-white text-xl mb-2">
              Meter Number
            </label>
            <input
              type="text"
              id="meterNumber"
              name="meterNumber"
              placeholder="meter number"
              className="w-full border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-4 font-mono"
              value={formData.meterNumber}
              onChange={handleChange}
            />
          </div>

          {/* Meter Size */}
          <div>
            <label htmlFor="meterSize" className="block text-[#1e1e1e] dark:text-white text-xl mb-2">
              Meter Size
            </label>
            <input
              type="text"
              id="meterSize"
              name="meterSize"
              placeholder="meter size"
              className="w-full border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-4 font-mono"
              value={formData.meterSize}
              onChange={handleChange}
            />
          </div>

          {/* Operator Notes */}
          <div>
            <label htmlFor="operatorNotes" className="block text-[#1e1e1e] dark:text-white text-xl mb-2">
              Operator Notes
            </label>
            <textarea
              id="operatorNotes"
              name="operatorNotes"
              placeholder="Enter notes here..."
              className="w-full border border-[#d9d9d9] dark:border-gray-700 bg-white dark:bg-gray-800 text-[#1e1e1e] dark:text-white rounded-lg p-4 h-32 font-mono"
              value={formData.operatorNotes}
              onChange={handleChange}
            />
          </div>

          {/* Photo Upload */}
          <div>
            <label className="block text-[#1e1e1e] dark:text-white text-xl mb-2">Photos</label>
            <div className="border-2 border-dashed border-[#d9d9d9] dark:border-gray-700 rounded-lg p-8 flex flex-col items-center justify-center">
              <Camera size={48} className="text-[#a5a5a5] dark:text-gray-400 mb-2" />
              <p className="text-[#6b7280] dark:text-gray-400 text-center font-mono">Tap to add photos</p>
            </div>
          </div>

          {/* Submit Button */}
          <button type="submit" className="w-full bg-[#f47e20] text-white font-bold py-4 px-6 rounded-lg text-xl">
            Submit Scan
          </button>
        </div>
      </form>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-[#e5e7eb] dark:border-gray-700 py-2 max-w-md mx-auto">
        <div className="flex justify-around items-center">
          <Link href="/" className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#6b7280] dark:text-gray-400">
              <Home strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono">Home</span>
          </Link>
          <Link href="/sites" className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#6b7280] dark:text-gray-400">
              <MapPin strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono">Sites</span>
          </Link>
          <div className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#f47e20]">
              <Scan strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#f47e20] mt-1 font-mono">New Scan</span>
          </div>
          <Link href="/schedule" className="flex flex-col items-center">
            <div className="w-6 h-6 text-[#6b7280] dark:text-gray-400">
              <Calendar strokeWidth={1.5} />
            </div>
            <span className="text-xs text-[#6b7280] dark:text-gray-400 mt-1 font-mono">Schedule</span>
          </Link>
        </div>
      </div>
    </div>
  )
}

